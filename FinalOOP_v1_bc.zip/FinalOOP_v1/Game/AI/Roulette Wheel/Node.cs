﻿using System.Collections;
using System.Collections.Generic;

public abstract class Node
{
    public abstract void Execute();
}
