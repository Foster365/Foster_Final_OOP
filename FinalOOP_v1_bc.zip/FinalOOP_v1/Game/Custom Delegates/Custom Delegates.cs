﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game
{

    //public delegate void SimpleEventHandler();
    //public delegate void SimpleEventHandler<T>(T value);
    //public delegate void SimpleEventHandler<T1, T2>(T1 value1, T2 value2);
    //public delegate void SimpleEventHandler<T1, T2, T3>(T2 value1, T2 value2, T3 value3);
    
}
